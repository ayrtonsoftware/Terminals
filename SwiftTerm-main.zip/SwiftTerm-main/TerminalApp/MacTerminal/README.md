This is an example application that shows the AppKit SwiftTerm in action, the UI
is just there to showcase the NSView.