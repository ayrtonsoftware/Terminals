import XCTest

import SwiftTermTests

var tests = [XCTestCaseEntry]()
tests += SwiftTermTests.allTests()
XCTMain(tests)
