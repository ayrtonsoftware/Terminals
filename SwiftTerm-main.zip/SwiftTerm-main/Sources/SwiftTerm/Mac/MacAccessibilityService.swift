//
//  File.swift
//  
//
//  Created by Miguel de Icaza on 3/5/20.
//

import Foundation

class AccessibilityService {
    func invalidate ()
    {
        
    }
}
